# Heads up!
These protobufs in this repository are automatically generated from Vectara and
the repository is read-only for the general public.  As a result, we do not
accept pull requests to this GitHub repository.

If you have feedback on Vectara or its APIs, please let us know in our
forums: https://discuss.vectara.com/
